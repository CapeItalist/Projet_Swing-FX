package exotptest.swing;

import javax.swing.JFrame;

public class IHMSwing extends JFrame{
    public IHMSwing() { }
}
